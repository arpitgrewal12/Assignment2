const express = require('express')
const path = require('path')
const PORT = process.env.PORT || 5000

/*
express()
  .use(express.static(path.join(__dirname, 'public')))
  .set('views', path.join(__dirname, 'views'))
  .set('view engine', 'ejs')
  .get('/', (req, res) => res.render('pages/index'))
  .listen(PORT, () => console.log(`Listening on ${ PORT }`))
*/

//connecting to database
const { Pool }=require('pg');
//Pool is a constructor
var pool;
pool= new Pool({
connectionString:'postgres://postgres:9789@localhost/person'
//THE ABOVE IS TO WORK locally
//THE BELOW IS TO WORK ON HEROKU
//connectionString :process.env.DATABASE_URL
});

//We are just creating an object app to create the function express.And then we are calling it just like we call objects.
var app =express();
app.use(express.json());
app.use(express.urlencoded({extended:false}));
  app.use(express.static(path.join(__dirname, 'public')));
  app.set('views', path.join(__dirname, 'views'));
  app.set('view engine', 'ejs');


  app.get('/', (req, res) => res.render('pages/index'));

  /*
  app.get('/database',(req,res)=> {
    var data={results:[2,3,4,5,6]};
    res.render('pages/db',data);
  });
  */

    app.get('/database',(req,res)=> {
      var getUsersQuery=`SELECT * FROM prsn`;// we are trying to get rows from here
      pool.query(getUsersQuery, (error,result)=>{
        if(error)
        res.end(error); // means we are ending the error and sending it as a response
        // if there is no error:
        var results={'rows':result.rows} //result is an object //'rows' is a parameter
        // result.rows is an array that contains the rows in the database table
      res.render('pages/db',results);//  we are sending the results to the db.ejs
    })
  });

  app.get('/database/:pid',(req,res)=>{
    var id=req.params.pid;
    console.log(req.params.pid);
    //search the database using the uid
    //try to invoke a query over here just like select * from user where uid=123 or uid =id that the user puts in
    res.send("got it!");
  });



  app.get('/adduser',(req,res)=>{
    console.log("post request for /adduser");
    var uname= req.body.uname;
    var age=req.body.age;
    res.send(`username: ${uname},age:${age}`);
  });
//to search a user with a particular id
  app.get('/users/:id',(req,res)=>{
    var uid=req.params.id;
    console.log(req.params.id);
    //search the database using the uid
    //try to invoke a query over here just like select * from user where uid=123 or uid =id that the user puts in
    res.send("got it!");
  });


  app.listen(PORT, () => console.log(`Listening on ${ PORT }`));
  //It means the port which is being used.
  //If in production, we do not have environment port and the file is not on heroku and we are running the local
  //file locally, then the port which we will be using is 5000
