
//var a=window.prompt("Tell me your name", "Name");
//window.alert("Hello"+a);

//function is an object as well

//func1(1,2,3); //this will work as func1 is already defined

//function func1(a,b,c){
//  console.log(a+b+c);
//}

//var func2=function(){
//  console.log("hello world");
//}

//func2();//however this would not work because function is treated as an object and theen later assigned to a avriable.
//It will work if we writee eit after the declaration of variable func2.


//--sorting arrays
function asc(a,b){ //we are making an ascending function and we will use  it as a comparing function.
  // asc is an object and we can pass it into the function call of sort.
  return a-b;
}


var arr=[15,22,13,4,54,5,76];
arr.sort(asc); // example of a call back function

//for(i=0;i<arr.length;i++){
//  console.log(arr[i]);
//}

//other way to write a for loop for array:

//for(item in arr){
//  console.log(arr[item]);
//}

var x =arr.every(function(val){ // It will return true if every onee of the values are greater than 3.
                                //Just like every, we have other functions in built like sum etc.
                                //Also, we can pass function definition anonymously other than specifying the function name.
  return val>3;
});
console.log(x);
