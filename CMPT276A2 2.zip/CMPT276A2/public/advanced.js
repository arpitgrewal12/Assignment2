//JS VARIABLE SCOPE
//global
//function -var
//block- let
/*
function myfunc(){
//  var  v="myfunc_var";
 v="myfunc_var";
  let le="myfunct_let";
  console.log(v);
  console.log(le);
  //for (var i=0;i<10;i++){
    //console.log(i);
  //}
//  console.log(i); //this does i=10,.

  for (let i=0;i<10;i++){
    console.log(i);
  }
  //console.log(i); //this does not print i=10,.

}

myfunc();
console.log(v);// it does print v because it is global scope
//console.log(le);// it does not print le because it is out of scope of block
*/
var cb1=()=>{console.log("cb1");}
var cb2=()=>{console.log("cb2");}
console.log("start....");
setTimeout(cb1,1000);
setTimeout(cb2,500);
console.log("end...");   
