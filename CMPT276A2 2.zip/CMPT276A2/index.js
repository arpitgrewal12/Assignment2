const express = require('express')
const path = require('path')
const PORT = process.env.PORT || 5000

//connecting to database
const { Pool }=require('pg');
//Pool is a constructor
var pool;
pool= new Pool({
//connectionString:'postgres://postgres:9789@localhost/person'
//THE ABOVE IS TO WORK locally
//THE BELOW IS TO WORK ON HEROKU
connectionString :process.env.DATABASE_URL
});

//We are just creating an object app to create the function express.And then we are calling it just like we call objects.
var app =express();
app.use(express.json());
app.use(express.urlencoded({extended:false}));
  app.use(express.static(path.join(__dirname, 'public')));
  app.set('views', path.join(__dirname, 'views'));
  app.set('view engine', 'ejs');


  app.get('/', (req, res) => res.render('pages/index'));
  app.get('/database',(req,res)=> {
      var getUsersQuery=`SELECT * FROM prsn`;// we are trying to get rows from here
      pool.query(getUsersQuery, (error,result)=>{
        if(error)
        res.end(error); // means we are ending the error and sending it as a response
        // if there is no error:
        var results={'rows':result.rows} //result is an object //'rows' is a parameter
        // result.rows is an array that contains the rows in the database table
      res.render('pages/ad',results);//  we are sending the results to the db.ejs
    })
  });

   app.post('/adduser',(req,res)=>{
    console.log("post request for /adduser");
    var id=req.body.id;
    var name= req.body.name;
    var height=req.body.height;
    var size=req.body.size;
    var type=req.body.type;
    var adduser = `INSERT INTO prsn VALUES (${id},'${name}',${height},${size},'${type}')`;
    pool.query(adduser,(error,result)=>{
      if (error){
        throw error;
     }
       else{
       console.log("success");

     }
    })
     res.render('pages/sd');
  });

  app.post('/deleteuser',(req,res)=>{
    var id=req.body.id;
    var getQuery=`DELETE FROM prsn WHERE pid=${id}`;
    pool.query(getQuery,(error,result)=>{
      if (error){
        throw error;
     }
     else{
       console.log("success");
     }
    })
  res.render('pages/sd');
  });

  app.post('/viewuser',(req,res)=> {
    var id=req.body.id;
    var getUserQuery=`SELECT * FROM prsn WHERE pid=${id}`;// we are trying to get rows from here
    pool.query(getUserQuery, (error,result)=>{
      if(error)
      res.end(error); // means we are ending the error and sending it as a response
      // if there is no error:
      var results={'rows':result.rows} //result is an object //'rows' is a parameter
      // result.rows is an array that contains the rows in the database table
    res.render('pages/viewuser',results);//  we are sending the results to the db.ejs
  })
});
app.listen(PORT, () => console.log(`Listening on ${ PORT }`));
  //It means the port which is being used.
  //If in production, we do not have environment port and the file is not on heroku and we are running the local
  //file locally, then the port which we will be using is 5000
